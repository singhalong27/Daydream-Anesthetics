import React, { useState } from "react";
import Head from "next/head";
import Image from "next/image";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { motion } from "framer-motion";

// (rest of content will be auto-inserted by canvas state)
